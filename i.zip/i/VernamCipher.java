/*Write programs to implement the following Substitution Cipher Techniques: - 
Vernam Cipher*/ 

package Vernam_Cipher;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.Random;
import static jdk.nashorn.internal.objects.NativeString.toUpperCase;
/**
 *
 * @author Admin
 */
public class VernamCipher {
       public static void main(String arg[]) throws IOException{
        System.out.println("\nReference - ");
        for(int i=1;i<27;i++)
            System.out.print((char)(i+64)+"-"+i+"  ");
        DataInputStream d=new DataInputStream(System.in);
        System.out.print("\n\nEnter the Plain Text : ");
        String plainText=d.readLine();
        plainText=toUpperCase(plainText);
        String modPlainText="";
        //code to remove the whitespaces
            for(int k=0;k<plainText.length();k++){
                char c=plainText.charAt(k);
                if(c>='A'&&c<='Z'){
                    modPlainText+=c;
                }
            }
        //Generate Random one-time pad
        String oneTimePad="";
        String cipher="";
        for(int k=0;k<modPlainText.length();k++){
        Random rand=new Random();
        int randNum=rand.nextInt(26)+1;
        oneTimePad+=(char)(randNum+64);
        }
        System.out.println("\n||\tPlain\t||\tOne-Time\t||\tInitial\t\t||\tMod 27\t\t||\tCipher\t||");
        System.out.println("||\tText\t||\tPad\t\t||\tTotal\t\t||\t(if>26)\t\t||\tText\t||");
        System.out.println("----------------------------------------------------------------------------------------------------------");
        for(int k=0;k<modPlainText.length();k++){
            int a=(int)(modPlainText.charAt(k)-64);
            int b=(int)(oneTimePad.charAt(k)-64);
            if((a+b)>26)
            {
                System.out.println("||\t"+(char)(a+64)+" ("+a+")\t||\t"+(char)(b+64)+" ("+b+")\t\t||\t"+(a+b)+"\t\t||\t"+((a+b)-26)+"\t\t||\t"+(char)(((a+b)-26)+64)+"\t||");
                cipher+=(char)(((a+b)-26)+64);
            }
            else{
                System.out.println("||\t"+(char)(a+64)+" ("+a+")\t||\t"+(char)(b+64)+" ("+b+")\t\t||\t"+(a+b)+"\t\t||\t"+(a+b)+"\t\t||\t"+(char)((a+b)+64)+"\t||");
                cipher+=(char)(((a+b)-26)+64);
            }  
        }
        System.out.println("\nCipher Text : "+cipher);  
    }
}
