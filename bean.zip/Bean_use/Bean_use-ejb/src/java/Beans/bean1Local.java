/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import javax.ejb.Local;

/**
 *
 * @author CS12
 */
@Local
public interface bean1Local {

    Integer addition(int a, int b);

    Integer subtraction(int a, int b);

    Integer multiplication(int a, int b);

    Integer division(int a, int b);
    
}
