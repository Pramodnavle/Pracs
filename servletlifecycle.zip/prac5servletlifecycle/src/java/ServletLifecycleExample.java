/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author SYCS24
 */
@WebServlet(urlPatterns = {"/ServletLifecycleExample"})
public class ServletLifecycleExample extends HttpServlet {

     @Override
    public void init() {
        // initialize the servlet, and print something in the console.
        System.out.println("Servlet Initialized!");
    }

    @Override
    public void service(ServletRequest request, ServletResponse response)
            throws ServletException, IOException {
        
        // the service method will 
        response.setContentType("text/html");
        
        PrintWriter out = response.getWriter();
        out.println("Servlet called!");
    }
    
    @Override
    public void destroy() {
        // close connections etc.
        System.out.println("Servlet Destroyed!");
       
    }
}
   

