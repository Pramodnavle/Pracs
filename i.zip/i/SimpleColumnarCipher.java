/*Write programs to implement the following Transposition Cipher Techniques: - 
SimpleColumnarCipher */ 

package SimpleColumnarCipher;

import java.io.DataInputStream;
import java.io.IOException;
import java.util.Arrays;
/**
 *
 * @author Admin
 */
public class SimpleColumnarCipher {
      public static String sortString(String inputString){
        char tempArray[]=inputString.toCharArray();
        Arrays.sort(tempArray);
        return new String(tempArray);
    }
    public static void main(String arg[]) throws IOException{
        DataInputStream d=new DataInputStream(System.in);
        String plaintext="",key,ciphertext="";
        int pos=0;
        System.out.print("\nEnter 1 for Encryption and 2 for Decryption : ");
        int choice=Integer.parseInt(d.readLine());
        if(choice==1){
            System.out.print("\nEnter the Plaintext : ");
            plaintext=d.readLine();
            System.out.print("\nEnter the key : ");
            key=d.readLine();
            int y=key.length();
            int strlen=plaintext.length();
            int x=(strlen/y)+1;
            char[][] matrix=new char[x][y];
            String sorted=sortString(key);
            for(int i=0;i<x;i++){
                for(int j=0;j<y;j++){
                    if(pos<strlen){
                        matrix[i][j]=plaintext.charAt(pos);
                        pos++; 
                        System.out.print(matrix[i][j]+"\t");
                    }
                    else
                        matrix[i][j]=' ';
                }
                System.out.println("\n");
            }
            for(int j=0;j<y;j++){
                int k=key.indexOf(sorted.charAt(j));
                for(int i=0;i<x;i++){
                    ciphertext+=matrix[i][k];
                }
            }
            System.out.print("Ciphertext : "+ciphertext);
        }
        if(choice==2){
            System.out.print("\nEnter the Ciphertext : ");
            ciphertext=d.readLine();
            System.out.print("\nEnter the key : ");
            key=d.readLine();
            int y=key.length();
            int strlen=ciphertext.length();
            int x=(strlen/y)+1;
            char[][] matrix=new char[x][y];
            String sorted=sortString(key);
            for(int j=0;j<y;j++){
            int k=key.indexOf(sorted.charAt(j));
            for(int i=0;i<x;i++){
                if(pos<strlen){
                matrix[i][k]=ciphertext.charAt(pos);
                pos++;
                }
                else
                    matrix[i][k]=' ';
            }
        }
        for(int i=0;i<x;i++){
            for(int j=0;j<y;j++){
                plaintext+=matrix[i][j];
            }
        }
        System.out.println("\nPlaintext : "+plaintext);
        } }
}
