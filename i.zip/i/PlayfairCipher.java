/*Write programs to implement the following Substitution Cipher Techniques: - 
PlayFairCipher*/ 

package PlayFairCipher;


import java.io.DataInputStream;
import java.io.IOException;
import static java.lang.Character.toUpperCase;
/**
 *
 * @author Admin
 */
public class PlayfairCipher {
    public static void main(String[] args) throws IOException {
        DataInputStream d=new DataInputStream(System.in);
        System.out.println("Enter the keyword : ");
        String keyword=d.readLine();        
        //Matrix formation
            char[][] matrix=new char[5][5];
            boolean keydone=false;
            int i=0,j=0;
            boolean filled=false;
            for(int k=0;k<keyword.length()&&keydone!=true;k++){
                filled=false;
                char c=keyword.charAt(k);
                c=toUpperCase(c);
                if(c>='A'&&c<='Z'){
                    //checking taht character is already inserted in matrix or not
                        for(int m=0;m<5;m++){
                            for(int n=0;n<5;n++){
                                if(matrix[m][n]==c)
                                    filled=true;
                            }
                        }
                    if(!filled){
                        matrix[i][j]=c;
                        j++;
                        if(j==5){
                            i++;
                            j=0;
                        }
                    }
                }
                if(k==keyword.length()-1)
                    keydone=true;
            }
            for(char k='A';k<='Z';k++){
                filled=false;
                for(int m=0;m<5;m++){
                    for(int n=0;n<5;n++){
                        if(matrix[m][n]==k)
                            filled=true;
                    }
                }
                if(!filled){
                    if(k=='J')
                        continue;
                    matrix[i][j]=k;
                    j++;
                    if(j==5){
                        i++;
                        j=0;
                    }
                }
            }
            System.out.print("\nTransformation Table\n");
            for(i=0;i<5;i++){
                for(j=0;j<5;j++){
                    System.out.print(" "+matrix[i][j]);
                }
                System.out.print("\n");
            } 
        
        //Dividing whloe string in two-two character blocks
            System.out.println("\nEnter the Plain Text : ");
            String plainText=d.readLine();
            plainText=plainText.toUpperCase();
            String modPlainText="";
            int l=0;
            char lastChar='.';
            for(int k=0;k<plainText.length();k++){
                if(l==2)
                    l=0;
                char c=plainText.charAt(k);
                if(c>='A'&&c<='Z'){
                    if(lastChar==c&&l==1){
                        modPlainText+='X';
                        lastChar='X';
                        k--;
                    }
                    else{
                        modPlainText+=c;
                        lastChar=c;
                    }
                    l++;
                    if(l==2)
                        modPlainText+=" ";
                }
            }
            if(l==1)
               modPlainText+='X'; 
            System.out.println("\nPlain Text : "+modPlainText);
    // Encryption process starts here
        l=0;
        String cipherText="";
        int x1=0,y1=0,x2=0,y2=0;
        //label to come directly here from inner loops
        //label always should be just above the loop
        outer:
        for(int k=0;k<modPlainText.length();k++){
            if(l==2)
                l=0;
            char c=modPlainText.charAt(k);
            if(c=='J')
                c='I';
            if(c>='A'&&c<='Z'){
                for(int m=0;m<5;m++){
                    for(int n=0;n<5;n++){
                        if(c==matrix[m][n]){
                            if(l==0){
                                x1=m;y1=n;
                                l++;
                                continue outer;
                            }
                            if(l==1)
                            {
                                x2=m;y2=n;
                                // Replacing plain text with cipher text 
                                if(x1==x2){
                                    y1++; y2++;
                                    if(y1==5)
                                        y1=0;
                                    if(y2==5)
                                        y2=0;
                                    cipherText+=matrix[x1][y1];
                                    cipherText+=matrix[x2][y2];
                                }
                                else if(y1==y2){
                                    x1++;  x2++;
                                    if(x1==5)
                                        x1=0;
                                    if(x2==5)
                                        x2=0;
                                    cipherText+=matrix[x1][y1];
                                    cipherText+=matrix[x2][y2];
                                }
                                else{
                                    cipherText+=matrix[x1][y2];
                                    cipherText+=matrix[x2][y1];
                                }
                                l++;
                                continue outer;
                            }   
                        }
                    }
                }
            }
            else
              cipherText+=c;  
        }
        System.out.println("\nCipher Text : "+cipherText+"\n");
       }
  }
