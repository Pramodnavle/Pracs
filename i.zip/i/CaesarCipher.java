/*Write programs to implement the following Substitution Cipher Techniques: - 
	Caesar Cipher.*/ 

package caesarcipher;
/**
 *
 * @author Admin
 */
public class CaesarCipher {
 public static StringBuffer encrypt(String text, int s) 
	{ 
		StringBuffer result= new StringBuffer(); 

		for (int i=0; i<text.length(); i++) 
		{ 
			if (Character.isUpperCase(text.charAt(i))) 
			{ 
				char ch = (char)(((int)text.charAt(i) + 
								s - 65) % 26 + 65); 
				result.append(ch); 
			} 
			else
			{ 
				char ch = (char)(((int)text.charAt(i) + 
								s - 97) % 26 + 97); 
				result.append(ch); 
			} 
		} 
		return result; 
	}
        // Encrypts text using a shift od s 
	public static StringBuffer decrypt(String text, int s) 
	{ 
		StringBuffer result= new StringBuffer(); 

		for (int i=0; i<text.length(); i++) 
		{ 
			if (Character.isUpperCase(text.charAt(i))) 
			{ 
				char ch = (char)(((int)text.charAt(i) - 
								s - 65) % 26 + 65); 
				result.append(ch); 
			} 
			else
			{ 
				char ch = (char)(((int)text.charAt(i) - 
								s - 97) % 26 + 97); 
				result.append(ch); 
			} 
		} 
		return result; 
	} 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
                    String text = "BHAVANS"; 
		int s = 3; 
		System.out.println("Text : " + text); 
		System.out.println("Shift : " + s); 
		System.out.println("Cipher: " + encrypt(text, s)); 
                StringBuffer df=encrypt(text, s);
                System.out.println("Plain text: " + decrypt(df.toString(), s)); 
	}     
}
