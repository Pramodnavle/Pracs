/*Write programs to implement the following Transposition Cipher Techniques: - 
Rail Fence Cipher */ 

package RailFenceCipher;
import java.io.DataInputStream;
import java.io.IOException;
/**
 *
 * @author Admin
 */
public class RailFenceCipher {
    public static void main(String arg[])throws IOException{
        DataInputStream d=new DataInputStream(System.in);
        System.out.print("\nEnter the plain text : ");
        String plainText=d.readLine();
        //Encryption
        String cipherText="";
        for(int i=0;i<plainText.length();i+=2)
            cipherText+=plainText.charAt(i);
        for(int i=1;i<plainText.length();i+=2)
            cipherText+=plainText.charAt(i); 
        System.out.println("\nCipher Text : "+cipherText);  
        //Decryption
        plainText="";
        int len=cipherText.length();
        if(len%2==0){
            for(int i=0;i<(len/2);i++){
                plainText+=cipherText.charAt(i);
                plainText+=cipherText.charAt(i+(len/2));
            }        
        }
        else{
            for(int i=0;i<(len/2)+1;i++){
                plainText+=cipherText.charAt(i);
                if(i!=(len/2))
                plainText+=cipherText.charAt(i+(len/2)+1);
            }
        }
        System.out.println("\nPlain Text : "+plainText+"\n");
    }
}
