/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Student;

/**
 *
 * @author CS24
 */
public class NewClass implements java.io.Serializable {

    private String Name;
     public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }
    
    private String Username;
     public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }
    
    private String Course;
    
    public String getCourse() {
        return Course;
    }

    public void setCourse(String Course) {
        this.Course = Course;
    }
    

    
}
